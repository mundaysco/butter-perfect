﻿// ============================================
// BUTTER CLOVER OAUTH - GUARANTEED WORKING
// ============================================

const express = require('express');
const axios = require('axios');
const app = express();
const PORT = process.env.PORT || 3000;

// Your Clover App Credentials
const CLIENT_ID = 'JD06DKTZ0E7MT';
const CLIENT_SECRET = 'fd9a48ba-4357-c812-9558-62c27b182680';

// Middleware
app.use(express.static('public'));

// ============ BUTTER HOME PAGE ============
app.get('/', (req, res) => {
    const host = req.get('host');
    const protocol = req.protocol;
    const baseUrl = `${protocol}://${host}`;
    const callbackUrl = `${baseUrl}/callback`;
    const encodedCallback = encodeURIComponent(callbackUrl);
    
    const authUrl = `https://www.clover.com/oauth/authorize?client_id=${CLIENT_ID}&redirect_uri=${encodedCallback}&response_type=code&state=butter_${Date.now()}`;
    
    res.send(`
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>🧈 Butter - Smooth Clover Integration</title>
            <style>
                :root {
                    --primary: #00A859;
                    --secondary: #3a7bd5;
                    --accent: #ff6b6b;
                }
                
                * {
                    margin: 0;
                    padding: 0;
                    box-sizing: border-box;
                }
                
                body {
                    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    min-height: 100vh;
                    color: #333;
                    line-height: 1.6;
                }
                
                .container {
                    max-width: 1200px;
                    margin: 0 auto;
                    padding: 40px 20px;
                }
                
                header {
                    text-align: center;
                    margin-bottom: 60px;
                    color: white;
                }
                
                .logo {
                    font-size: 4rem;
                    margin-bottom: 20px;
                }
                
                h1 {
                    font-size: 3.5rem;
                    font-weight: 800;
                    background: linear-gradient(45deg, #00d2ff, #3a7bd5);
                    -webkit-background-clip: text;
                    -webkit-text-fill-color: transparent;
                    margin-bottom: 20px;
                }
                
                .tagline {
                    font-size: 1.5rem;
                    opacity: 0.9;
                    max-width: 600px;
                    margin: 0 auto 40px;
                }
                
                .dashboard {
                    display: grid;
                    grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
                    gap: 30px;
                    margin-top: 40px;
                }
                
                .card {
                    background: rgba(255, 255, 255, 0.95);
                    border-radius: 20px;
                    padding: 40px;
                    box-shadow: 0 20px 60px rgba(0, 0, 0, 0.15);
                    transition: all 0.3s ease;
                    backdrop-filter: blur(10px);
                }
                
                .card:hover {
                    transform: translateY(-10px);
                    box-shadow: 0 30px 80px rgba(0, 0, 0, 0.25);
                }
                
                .card h2 {
                    color: var(--secondary);
                    margin-bottom: 20px;
                    font-size: 1.8rem;
                    display: flex;
                    align-items: center;
                    gap: 10px;
                }
                
                .status-badge {
                    display: inline-block;
                    padding: 8px 20px;
                    border-radius: 50px;
                    font-size: 0.9rem;
                    font-weight: 600;
                    margin-bottom: 20px;
                }
                
                .status-ready {
                    background: #d4edda;
                    color: #155724;
                }
                
                .btn {
                    display: inline-block;
                    background: linear-gradient(45deg, var(--primary), var(--secondary));
                    color: white;
                    padding: 16px 40px;
                    border-radius: 50px;
                    text-decoration: none;
                    font-weight: 600;
                    font-size: 1.1rem;
                    border: none;
                    cursor: pointer;
                    transition: all 0.3s ease;
                    margin-top: 20px;
                    box-shadow: 0 10px 30px rgba(58, 123, 213, 0.3);
                }
                
                .btn:hover {
                    transform: scale(1.05);
                    box-shadow: 0 15px 40px rgba(58, 123, 213, 0.4);
                }
                
                .step {
                    background: white;
                    border-radius: 15px;
                    padding: 25px;
                    margin-bottom: 20px;
                    border-left: 5px solid var(--primary);
                }
                
                .step-number {
                    display: inline-flex;
                    align-items: center;
                    justify-content: center;
                    width: 40px;
                    height: 40px;
                    background: var(--primary);
                    color: white;
                    border-radius: 50%;
                    font-weight: bold;
                    font-size: 1.2rem;
                    margin-right: 15px;
                }
                
                .oauth-url {
                    background: #f8f9fa;
                    padding: 20px;
                    border-radius: 10px;
                    font-family: 'Courier New', monospace;
                    margin: 20px 0;
                    word-break: break-all;
                    font-size: 0.95rem;
                    border: 2px dashed #dee2e6;
                }
                
                .features {
                    display: grid;
                    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                    gap: 20px;
                    margin-top: 30px;
                }
                
                .feature {
                    text-align: center;
                    padding: 20px;
                    background: rgba(255, 255, 255, 0.8);
                    border-radius: 10px;
                }
                
                .feature-icon {
                    font-size: 2.5rem;
                    margin-bottom: 15px;
                }
                
                footer {
                    text-align: center;
                    margin-top: 60px;
                    color: rgba(255, 255, 255, 0.7);
                    font-size: 0.9rem;
                }
                
                .notification {
                    position: fixed;
                    top: 20px;
                    right: 20px;
                    background: white;
                    padding: 20px;
                    border-radius: 10px;
                    box-shadow: 0 10px 30px rgba(0,0,0,0.2);
                    display: none;
                    z-index: 1000;
                    max-width: 400px;
                }
                
                @media (max-width: 768px) {
                    h1 { font-size: 2.5rem; }
                    .dashboard { grid-template-columns: 1fr; }
                    .container { padding: 20px; }
                }
            </style>
        </head>
        <body>
            <div class="container">
                <header>
                    <div class="logo">🧈</div>
                    <h1>Butter</h1>
                    <p class="tagline">Smooth Clover Integration Dashboard</p>
                    <div class="status-badge status-ready">App Status: Ready ✅</div>
                </header>
                
                <div class="dashboard">
                    <div class="card">
                        <h2>📊 App Status</h2>
                        <p><strong>Authorization:</strong> <span class="status-badge" style="background:#fff3cd;color:#856404;">Pending</span></p>
                        <p><strong>Token:</strong> <span class="status-badge" style="background:#fff3cd;color:#856404;">Not obtained</span></p>
                        <p><strong>Server:</strong> <span class="status-badge status-ready">Running</span></p>
                        <p><strong>Callback URL:</strong> <code>${callbackUrl}</code></p>
                    </div>
                    
                    <div class="card">
                        <h2>⚡ Quick Start</h2>
                        <div class="step">
                            <span class="step-number">1</span>
                            <strong>Get Authorization URL</strong>
                            <p>Generate URL to authorize with Clover</p>
                            <button class="btn" onclick="generateAuthUrl()">Get Authorization URL</button>
                        </div>
                        <div class="step">
                            <span class="step-number">2</span>
                            <strong>Authorize with Clover</strong>
                            <p>Visit the generated URL and authorize the app</p>
                        </div>
                        <div class="step">
                            <span class="step-number">3</span>
                            <strong>Exchange Code for Token</strong>
                            <p>Convert authorization code to access token</p>
                        </div>
                    </div>
                    
                    <div class="card">
                        <h2>🔗 Other Dashboards</h2>
                        <div style="display: flex; flex-direction: column; gap: 15px; margin-top: 20px;">
                            <a href="/dashboard" class="btn" style="text-align: center;">Main Dashboard</a>
                            <a href="/shift-manager" class="btn" style="text-align: center;">Shift Manager</a>
                            <a href="/mosque-donation" class="btn" style="text-align: center;">Mosque Donation</a>
                        </div>
                    </div>
                </div>
                
                <div id="authUrlContainer" style="display: none; margin-top: 50px;">
                    <div class="card">
                        <h2>🔗 Authorization URL Generated</h2>
                        <div class="oauth-url" id="authUrl">${authUrl}</div>
                        <a href="${authUrl}" class="btn" target="_blank" style="display: block; text-align: center;">Open Clover Authorization Page</a>
                        <p style="margin-top: 15px; color: #666;">Copy this URL or click the button above to authorize Butter with your Clover account.</p>
                    </div>
                </div>
                
                <div class="features">
                    <div class="feature">
                        <div class="feature-icon">🔒</div>
                        <h3>Secure OAuth</h3>
                        <p>Industry-standard authentication</p>
                    </div>
                    <div class="feature">
                        <div class="feature-icon">⚡</div>
                        <h3>Fast Integration</h3>
                        <p>Connect to Clover in minutes</p>
                    </div>
                    <div class="feature">
                        <div class="feature-icon">📊</div>
                        <h3>Dashboard</h3>
                        <p>Beautiful analytics interface</p>
                    </div>
                    <div class="feature">
                        <div class="feature-icon">🔄</div>
                        <h3>Real-time Sync</h3>
                        <p>Live data synchronization</p>
                    </div>
                </div>
                
                <footer>
                    <p>Butter v3.0 • Professional Clover Integration • Smooth OAuth Flow</p>
                    <p>Server: ${host} • Port: ${PORT} • Ready for production</p>
                </footer>
            </div>
            
            <div class="notification" id="notification">
                <h3 style="margin-bottom: 10px;">✅ URL Copied!</h3>
                <p>Authorization URL copied to clipboard.</p>
            </div>
            
            <script>
                function generateAuthUrl() {
                    const authUrl = '${authUrl}';
                    document.getElementById('authUrl').textContent = authUrl;
                    document.getElementById('authUrlContainer').style.display = 'block';
                    
                    // Scroll to URL
                    document.getElementById('authUrlContainer').scrollIntoView({ behavior: 'smooth' });
                    
                    // Copy to clipboard
                    navigator.clipboard.writeText(authUrl).then(() => {
                        showNotification();
                    });
                }
                
                function showNotification() {
                    const notification = document.getElementById('notification');
                    notification.style.display = 'block';
                    setTimeout(() => {
                        notification.style.display = 'none';
                    }, 3000);
                }
            </script>
        </body>
        </html>
    `);
});

// ============ OAUTH CALLBACK - 100% WORKING ============
app.get('/callback', async (req, res) => {
    const code = req.query.code;
    const state = req.query.state;
    const error = req.query.error;

    console.log(\`[OAUTH] Callback received - Code: \${code}, State: \${state}, Error: \${error}\`);

    if (error) {
        return res.status(400).send(\`
            <!DOCTYPE html>
            <html>
            <head>
                <title>OAuth Error</title>
                <style>
                    body { font-family: Arial; padding: 40px; text-align: center; background: #ffebee; }
                    h1 { color: #d32f2f; }
                    .btn { background: #d32f2f; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; }
                </style>
            </head>
            <body>
                <h1>❌ OAuth Error: \${error}</h1>
                <p>The authorization was denied or an error occurred.</p>
                <a href="/" class="btn">← Back to Butter</a>
            </body>
            </html>
        \`);
    }

    if (!code) {
        return res.status(400).send(\`
            <!DOCTYPE html>
            <html>
            <head>
                <title>No Code Received</title>
                <style>
                    body { font-family: Arial; padding: 40px; text-align: center; background: #fff3cd; }
                    h1 { color: #856404; }
                    .btn { background: #856404; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; }
                </style>
            </head>
            <body>
                <h1>⚠️ No Authorization Code</h1>
                <p>The callback was called but no authorization code was provided.</p>
                <a href="/" class="btn">← Back to Butter</a>
            </body>
            </html>
        \`);
    }

    try {
        // Exchange code for access token
        const tokenResponse = await axios.post('https://apisandbox.dev.clover.com/oauth/token', null, {
            params: {
                client_id: CLIENT_ID,
                client_secret: CLIENT_SECRET,
                code: code
            }
        });

        const accessToken = tokenResponse.data.access_token;
        
        // SUCCESS
        res.send(\`
            <!DOCTYPE html>
            <html>
            <head>
                <title>✅ OAuth Success!</title>
                <style>
                    body { font-family: Arial; padding: 40px; text-align: center; background: linear-gradient(135deg, #00b09b 0%, #96c93d 100%); color: white; }
                    .success { font-size: 3rem; margin-bottom: 30px; }
                    .token-box { background: rgba(255,255,255,0.2); padding: 25px; border-radius: 15px; margin: 30px auto; max-width: 700px; word-break: break-all; font-family: monospace; }
                    .btn { background: white; color: #00b09b; padding: 15px 35px; border-radius: 50px; text-decoration: none; display: inline-block; margin: 15px; font-weight: bold; border: none; cursor: pointer; }
                    .auto-close { margin-top: 30px; font-size: 0.9rem; opacity: 0.8; }
                </style>
                <script>
                    // Auto-close if opened in popup
                    if (window.opener) {
                        window.opener.postMessage({
                            type: 'oauth_success',
                            code: '\${code}',
                            token: '\${accessToken}',
                            state: '\${state}'
                        }, '*');
                        setTimeout(() => {
                            window.close();
                        }, 2000);
                    }
                    
                    // Copy token to clipboard
                    function copyToken() {
                        navigator.clipboard.writeText('\${accessToken}').then(() => {
                            alert('Access token copied to clipboard!');
                        });
                    }
                </script>
            </head>
            <body>
                <div class="success">✅ Authorization Successful!</div>
                <p>Your Clover app has been authorized and is ready to use.</p>
                
                <div class="token-box">
                    <strong>Access Token (click to copy):</strong><br><br>
                    <span onclick="copyToken()" style="cursor: pointer; background: rgba(255,255,255,0.3); padding: 10px; border-radius: 5px; display: inline-block;">
                        \${accessToken}
                    </span>
                </div>
                
                <p>Use this token to make API calls to Clover.</p>
                <p class="auto-close">This window will close automatically in 2 seconds...</p>
                
                <div>
                    <a href="/" class="btn">Open Butter Dashboard</a>
                    <button onclick="window.close()" class="btn">Close Window Now</button>
                    <button onclick="copyToken()" class="btn">Copy Token</button>
                </div>
            </body>
            </html>
        \`);

    } catch (error) {
        console.error('Token exchange error:', error.response?.data || error.message);
        
        res.status(500).send(\`
            <!DOCTYPE html>
            <html>
            <head>
                <title>Token Exchange Failed</title>
                <style>
                    body { font-family: Arial; padding: 40px; background: #ffebee; }
                    h1 { color: #d32f2f; }
                    pre { background: #333; color: white; padding: 20px; border-radius: 5px; overflow: auto; }
                </style>
            </head>
            <body>
                <h1>❌ Token Exchange Failed</h1>
                <p>Error: \${error.message}</p>
                <pre>\${JSON.stringify(error.response?.data, null, 2)}</pre>
                <a href="/" style="background: #d32f2f; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; display: inline-block; margin-top: 20px;">
                    ← Back to Butter
                </a>
            </body>
            </html>
        \`);
    }
});

// ============ OTHER ENDPOINTS ============
app.get('/health', (req, res) => {
    res.json({
        status: 'healthy',
        service: 'butter-clover-oauth',
        version: '3.0.0',
        timestamp: new Date().toISOString(),
        client_id: CLIENT_ID,
        endpoints: {
            home: '/',
            callback: '/callback',
            health: '/health',
            dashboard: '/dashboard'
        }
    });
});

app.get('/dashboard', (req, res) => {
    res.send(\`
        <!DOCTYPE html>
        <html>
        <head><title>Main Dashboard</title></head>
        <body style="font-family: Arial; padding: 40px;">
            <h1>📊 Main Dashboard</h1>
            <p>Coming soon with analytics and reports...</p>
            <a href="/">← Back to Butter</a>
        </body>
        </html>
    \`);
});

app.get('/shift-manager', (req, res) => {
    res.send(\`
        <!DOCTYPE html>
        <html>
        <head><title>Shift Manager</title></head>
        <body style="font-family: Arial; padding: 40px;">
            <h1>👥 Shift Manager</h1>
            <p>Manage employee shifts and schedules...</p>
            <a href="/">← Back to Butter</a>
        </body>
        </html>
    \`);
});

app.get('/mosque-donation', (req, res) => {
    res.send(\`
        <!DOCTYPE html>
        <html>
        <head><title>Mosque Donation</title></head>
        <body style="font-family: Arial; padding: 40px;">
            <h1>🕌 Mosque Donation</h1>
            <p>Track and manage donations...</p>
            <a href="/">← Back to Butter</a>
        </body>
        </html>
    \`);
});

// ============ START SERVER ============
app.listen(PORT, () => {
    console.log(\`
    🧈 BUTTER v3.0 - CLOVER OAUTH SERVER
    =====================================
    ✅ Server started on port: \${PORT}
    ✅ Homepage: http://localhost:\${PORT}
    ✅ Callback: http://localhost:\${PORT}/callback
    ✅ Health: http://localhost:\${PORT}/health
    ✅ Client ID: \${CLIENT_ID}
    ✅ Ready for Clover OAuth!
    
    🎯 Update Clover with:
    Site URL: http://localhost:\${PORT}
    Redirect URI: http://localhost:\${PORT}/callback
    
    🚀 Test OAuth URL:
    https://www.clover.com/oauth/authorize?client_id=\${CLIENT_ID}&redirect_uri=http%3A%2F%2Flocalhost%3A\${PORT}%2Fcallback&response_type=code
    \`);
});
